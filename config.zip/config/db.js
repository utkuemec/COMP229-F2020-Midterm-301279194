module.exports = 
{
    //"URI": "mongodb://localhost/book_store"
    "URI": "mongodb+srv://Utkuemec:Utkuemec@cluster0.jfdl5bg.mongodb.net/mean-midterm?retryWrites=true&w=majority",
    "Secret": 'SomeSecret'
    
}